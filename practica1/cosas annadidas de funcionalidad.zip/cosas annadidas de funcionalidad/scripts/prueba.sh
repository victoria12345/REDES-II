#!/bin/bash
 
echo -e "Escribe tu nombre, por favor: "
read nombre
echo "Encantado de saludarte, $nombre"
